import React from 'react'

// step1: 创建Context对象
const FieldContext = React.createContext()

export default FieldContext